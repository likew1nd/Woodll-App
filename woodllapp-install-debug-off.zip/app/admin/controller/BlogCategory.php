<?php
/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 2019/3/18
 * Time: 22:17
 */

namespace app\admin\controller;


class BlogCategory {
    protected function test()
    {
        return "hello_test";
    }

}
