<?php

// 历史版本会在公网请求此文件时删除 install.lock，导致已安装站点可被重新安装。
// 保留文件仅用于兼容旧链接，任何请求都直接拒绝。
http_response_code(404);
header('Content-Type: text/plain; charset=UTF-8');
echo 'Not Found';
exit;
