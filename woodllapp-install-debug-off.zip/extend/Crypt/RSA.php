<?php
/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 2019/6/18
 * Time: 4:07
 */

namespace Crypt;


class RSA{
    private static $_privkey = '';
    private static $_pubkey = '';
    private static $_isbase64 = false;
    /**
     * 鍒濆鍖杒ey鍊?
     * @param  string  $privkey  绉侀挜
     * @param  string  $pubkey   鍏挜
     * @param  boolean $isbase64 鏄惁base64缂栫爜
     * @return null
     */
    public  function init($privkey, $pubkey, $isbase64=false){
        self::$_privkey = $privkey;
        self::$_pubkey = $pubkey;
        self::$_isbase64 = $isbase64;
    }
    /**
     * 绉侀挜鍔犲瘑
     * @param  string $data 鍘熸枃
     * @return string       瀵嗘枃
     */
    public  function priv_encode($data){
        $outval = '';
        $res = openssl_pkey_get_private(self::$_privkey);
        openssl_private_encrypt($data, $outval, $res);
        if(self::$_isbase64){
            $outval = base64_encode($outval);
        }
        return $outval;
    }
    /**
     * 鍏挜瑙ｅ瘑
     * @param  string $data 瀵嗘枃
     * @return string       鍘熸枃
     */
    public  function pub_decode($data){
        $outval = '';
        if(self::$_isbase64){
            $data = base64_decode($data);
        }
        $res = openssl_pkey_get_public(self::$_pubkey);
        openssl_public_decrypt($data, $outval, $res);
        return $outval;
    }
    /**
     * 鍏挜鍔犲瘑
     * @param  string $data 鍘熸枃
     * @return string       瀵嗘枃
     */
    public  function pub_encode($data){
        $outval = '';
        $res = openssl_pkey_get_public(self::$_pubkey);
        openssl_public_encrypt($data, $outval, $res);
        if(self::$_isbase64){
            $outval = base64_encode($outval);
        }
        return $outval;
    }
    /**
     * 绉侀挜瑙ｅ瘑
     * @param  string $data 瀵嗘枃
     * @return string       鍘熸枃
     */
    public  function priv_decode($data){
        $outval = '';
        if(self::$_isbase64){
            $data = base64_decode($data);
        }
        $res = openssl_pkey_get_private(self::$_privkey);
        openssl_private_decrypt($data, $outval, $res);
        return $outval;
    }
    /**
     * 鍒涘缓涓€缁勫叕閽ョ閽?
     * @return array 鍏挜绉侀挜鏁扮粍
     */
    public function new_rsa_key(){
        $config = array(
            "private_key_bits"     => 2048,           //瀛楄妭鏁? 512 1024 2048  4096 绛?            "private_key_type"     => OPENSSL_KEYTYPE_RSA,
        );
        $opensslConf = config('opensslConf');
        if (!empty($opensslConf) && is_file($opensslConf)) {
            $config['config'] = $opensslConf; // 璺緞
        }
        $res = openssl_pkey_new($config);
        if ( $res == false ) return false;
        //浠庡緱鍒扮殑璧勬簮涓幏鍙栫閽ワ紝鎶婄閽ヨ祴缁?privKey
        openssl_pkey_export($res, $privKey, null, $config);
        //浠庡緱鍒扮殑璧勬簮涓幏鍙栧叕閽ワ紝杩斿洖鍏挜$pubKey
        $pubKey = openssl_pkey_get_details($res);
        $pubKey = $pubKey["key"];
        return array(
            'privkey' => $privKey,
            'pubkey'  => $pubKey
        );
    }
}
