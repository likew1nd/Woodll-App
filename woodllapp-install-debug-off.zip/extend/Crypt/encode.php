<?php
/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 2019/4/27
 * Time: 2:48
 */

namespace Crypt;


class encode
{
    public $key;

    public $type;

    function __construct($key, $type)
    { //构造方法
        $this->key = $key;
        $this->type = $type;
    }

    public function setKey($key, $salt)
    {
        $this->key = $key;
        $this->salt = $salt;
    }

    //加密
    public function su_encrypt($str)
    {
        $res = "";
        switch ($this->type) {
            case 0:
                $des = new \Crypt\Des();
                $res = $des->encryptDesEcbPKCS5($str, $this->key);
                break;
            case 1:
                $aes= new Aes();
                $res=$aes->encrypt($str, $this->key);
                break;
            default:
                $res = "没有选择加密方式";
        }
        return $this->rc4(strrev($this->key),$res);
    }
    public	function rc4($pwd, $data)//$pwd密钥 $data需加密字符串
    {
        $key[] ="";
        $box[] ="";
        $cipher="";
        $pwd_length = strlen($pwd);
        $data_length = strlen($data);

        for ($i = 0; $i < 256; $i++)
        {
            $key[$i] = ord($pwd[$i % $pwd_length]);
            $box[$i] = $i;
        }

        for ($j = $i = 0; $i < 256; $i++)
        {
            $j = ($j + $box[$i] + $key[$i]) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }

        for ($a = $j = $i = 0; $i < $data_length; $i++)
        {
            $a = ($a + 1) % 256;
            $j = ($j + $box[$a]) % 256;

            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;

            $k = $box[(($box[$a] + $box[$j]) % 256)];
            $cipher .= chr(ord($data[$i]) ^ $k);
        }
        // var_dump($cipher);
        //exit();
        return $cipher;
    }

//算法解密
    public function su_decrypt($str)
    {
        $str=$this->rc4(strrev($this->key),$str);
        $res = "";
        switch ($this->type) {
            case 0:
                $des = new \Crypt\Des();
                $res = $des->decryptDesEcbPKCS5($str, $this->key);
                break;
            case 1:
                $aes= new Aes();
                $res=$aes->decrypt($str, $this->key);
                break;
            default:
                $res = "没有选择解密方式";
        }
        return $res;
    }

//返回加密json
    public function encodeJson($data)
    {
        return $this->su_encrypt(json_encode($data, JSON_UNESCAPED_UNICODE), $this->key, $this->type);
    }
    //验证SIGN $data=json_decode后的数组
    public function verifySign($arr,$privateSalt)
    {
        //加密方式=MD5(appid+data+privateSalt+timestamp)
        if (!array_key_exists('data', $arr))return false; //不存在data字段
        if (!array_key_exists('appid', $arr))return false; //不存在appid字段
        if (!array_key_exists('timestamp', $arr))return false; //不存在timestamp字段
        if (!array_key_exists('sign', $arr))return false; //不存在sign字段
        $data=json_encode( count($arr['data'])==1?$arr['data'][0]:$arr['data'],JSON_UNESCAPED_UNICODE );
        $sign=md5(strrev(mb_convert_encoding($arr['appid'].$data.$privateSalt.$arr['timestamp'].strrev($arr['timestamp']."214783030"), 'gbk', 'auto'))  );
        return $sign==$arr['sign'];
    }
}
