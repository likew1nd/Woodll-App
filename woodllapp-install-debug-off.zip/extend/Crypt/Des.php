<?php
namespace Crypt;

class Des {
    public function __construct() {}

    public function getSKey($msg) {
        if (!$msg) {
            die('请输入参数');
        }

        return substr(md5($msg), 0, 8);
    }

    public function encryptDesEcbPKCS5($input, $key) {
        $input = $this->pkcs5_pad($input, 8);
        $data = $this->opensslDesEcb($input, $key, true);

        return $data === false ? false : base64_encode($data);
    }

    public function decryptDesEcbPKCS5($input, $key) {
        $raw = base64_decode($input);
        if ($raw === false) {
            return false;
        }

        $data = $this->opensslDesEcb($raw, $key, false);
        if ($data === false) {
            return false;
        }

        return $this->pkcs5_unpad($data);
    }

    private function pkcs5_pad($text, $blocksize) {
        $pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_repeat(chr($pad), $pad);
    }

    private function pkcs5_unpad($text) {
        $len = strlen($text);
        if ($len === 0) {
            return false;
        }

        $pad = ord($text[$len - 1]);
        if ($pad < 1 || $pad > 8 || $pad > $len) {
            return false;
        }

        if (substr($text, -$pad) !== str_repeat(chr($pad), $pad)) {
            return false;
        }

        return substr($text, 0, -$pad);
    }

    private function normalizeKey($key) {
        return substr(str_pad($key, 8, "\0"), 0, 8);
    }

    private function opensslDesEcb($data, $key, $encrypt) {
        $key8 = $this->normalizeKey($key);
        $options = OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING;

        if ($encrypt) {
            $result = openssl_encrypt($data, 'DES-ECB', $key8, $options);
        } else {
            $result = openssl_decrypt($data, 'DES-ECB', $key8, $options);
        }

        if ($result !== false) {
            return $result;
        }

        // OpenSSL 3 may disable single DES. DES-EDE3 with K1=K2=K3 is equivalent to DES.
        $key24 = str_repeat($key8, 3);
        if ($encrypt) {
            return openssl_encrypt($data, 'DES-EDE3', $key24, $options);
        }

        return openssl_decrypt($data, 'DES-EDE3', $key24, $options);
    }
}
