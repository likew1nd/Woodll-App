<?php
namespace Crypt;

class Aes {
    private $method = 'AES-128-ECB';

    public function encrypt($input = '', $key = '') {
        $input = $this->pkcs5_pad($input, 16);
        $data = openssl_encrypt($input, $this->method, $this->normalizeKey($key), OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING);

        return $data === false ? false : base64_encode($data);
    }

    private function pkcs5_pad($text, $blocksize) {
        $pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_repeat(chr($pad), $pad);
    }

    public function decrypt($sStr, $key) {
        $str = base64_decode($sStr);
        if ($str === false) {
            return false;
        }

        $data = openssl_decrypt($str, $this->method, $this->normalizeKey($key), OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING);
        if ($data === false) {
            return false;
        }

        return $this->pkcs5_unpad($data);
    }

    private function pkcs5_unpad($text) {
        $len = strlen($text);
        if ($len === 0) {
            return false;
        }

        $pad = ord($text[$len - 1]);
        if ($pad < 1 || $pad > 16 || $pad > $len) {
            return false;
        }

        if (substr($text, -$pad) !== str_repeat(chr($pad), $pad)) {
            return false;
        }

        return substr($text, 0, -$pad);
    }

    private function normalizeKey($key) {
        return substr(str_pad($key, 16, "\0"), 0, 16);
    }
}
