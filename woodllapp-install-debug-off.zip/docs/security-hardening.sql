-- Existing deployments: verify duplicate queries return no rows before adding indexes.
-- Replace yz_ when the installation uses a different table prefix.

UPDATE yz_soft_users su
JOIN yz_soft_list s ON s.id = su.sid
SET su.authorid = s.uid, su.sname = s.name
WHERE su.authorid IS NULL OR su.authorid <> s.uid;

UPDATE yz_cards c
JOIN yz_soft_list s ON s.id = c.sid
SET c.authorid = s.uid, c.sname = s.name
WHERE c.authorid IS NULL OR c.authorid <> s.uid;

UPDATE yz_su_login_record r
JOIN yz_soft_list s ON s.id = r.sid
SET r.authorid = s.uid, r.sname = s.name
WHERE r.authorid IS NULL OR r.authorid <> s.uid;

SELECT sid, username, COUNT(*) AS duplicate_count
FROM yz_soft_users
GROUP BY sid, username
HAVING COUNT(*) > 1;

SELECT sid, card_no, COUNT(*) AS duplicate_count
FROM yz_cards
GROUP BY sid, card_no
HAVING COUNT(*) > 1;

SELECT sid, ver, COUNT(*) AS duplicate_count
FROM yz_soft_ver
GROUP BY sid, ver
HAVING COUNT(*) > 1;

ALTER TABLE yz_soft_users
    MODIFY ip varchar(45) DEFAULT NULL,
    ADD UNIQUE KEY uk_soft_users_sid_username (sid, username),
    ADD KEY idx_soft_users_author_sid (authorid, sid),
    ADD KEY idx_soft_users_online_heart (isonline, heart_time);

ALTER TABLE yz_cards
    ADD UNIQUE KEY uk_cards_sid_card_no (sid, card_no),
    ADD KEY idx_cards_author_sid_status (authorid, sid, status);

ALTER TABLE yz_su_login_record
    MODIFY ip varchar(45) DEFAULT NULL,
    ADD KEY idx_su_login_record_eid (eid),
    ADD KEY idx_su_login_record_sid_status (sid, status),
    ADD KEY idx_su_login_record_author_status (authorid, status);

ALTER TABLE yz_login_record
    MODIFY ip varchar(45) DEFAULT NULL;

ALTER TABLE yz_soft_ver
    ADD UNIQUE KEY uk_soft_ver_sid_ver (sid, ver);
